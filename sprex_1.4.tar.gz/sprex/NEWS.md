# sprex 1.4

## Additions


## Changes

* added pct.range to clench function to specify minimum and maximum percentages of sample sizes
* changed argument m in expected.num.species to accept vectors and return a matrix

## Bug Fixes
